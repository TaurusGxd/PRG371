USE PRG
GO

INSERT INTO Register(register_id,student_id,student_name,student_email,student_address,student_password,course_name)
VALUES
(001,01,'John Doe','JD@gmail.com','123 Marryville str', 'JDrulez','WPR371'),
(002,02,'Mary Lynn','mlynn@gmail.com','123 Barryville str', 'marylynnonly','PRG371'),
(003,03,'Micheal Jackson','mj@gmail.com','123 Varryville str', 'BillieJean','LPR371'),
(004,04,'Elvis Moo','elvis@gmail.com','123 Arryville str', 'jailhouse','WPR371'),
(005,05,'Doja Dee','dojacat@gmail.com','123 Harryville str', 'attention','PRG371')
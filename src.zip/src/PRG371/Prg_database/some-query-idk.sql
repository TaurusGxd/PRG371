SELECT *
FROM Register
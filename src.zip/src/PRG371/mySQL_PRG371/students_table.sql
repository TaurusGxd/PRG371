

CREATE TABLE Students(student_id INT PRIMARY KEY,
student_name VARCHAR(50),
student_address VARCHAR(200),
student_email VARCHAR(200),
student_password VARCHAR(200));



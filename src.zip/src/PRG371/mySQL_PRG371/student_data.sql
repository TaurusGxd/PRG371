INSERT INTO Students(student_id,student_name,student_email,student_address,student_password)
VALUES
(01,'John Doe','JD@gmail.com','123 Marryville str', 'JDrulez'),
(02,'Mary Lynn','mlynn@gmail.com','123 Barryville str', 'marylynnonly'),
(03,'Micheal Jackson','mj@gmail.com','123 Varryville str', 'BillieJean'),
(04,'Elvis Moo','elvis@gmail.com','123 Arryville str', 'jailhouse'),
(05,'Doja Dee','dojacat@gmail.com','123 Harryville str', 'attention')
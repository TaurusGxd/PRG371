INSERT INTO Administrator (admin_id,admin_name,admin_password,contact)
VALUES
(01, 'Sara Lynn','admin123','0714458899'),
(02, 'Joe Cane','admin123','0628789011'),
(03, 'Thabo Bester','admin123','0826459900')
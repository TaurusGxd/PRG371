CREATE TABLE Administrator
(admin_id INT PRIMARY KEY,
admin_name VARCHAR(50),
admin_password VARCHAR(200),
contact VARCHAR(10));